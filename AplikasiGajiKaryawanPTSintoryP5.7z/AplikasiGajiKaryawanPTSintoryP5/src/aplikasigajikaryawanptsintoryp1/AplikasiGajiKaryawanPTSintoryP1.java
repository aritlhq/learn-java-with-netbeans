package aplikasigajikaryawanptsintoryp1;

import view.FormUtama;

public class AplikasiGajiKaryawanPTSintoryP1 {

    public static void main(String[] args) {
        new FormUtama().setVisible(true);
    }

}