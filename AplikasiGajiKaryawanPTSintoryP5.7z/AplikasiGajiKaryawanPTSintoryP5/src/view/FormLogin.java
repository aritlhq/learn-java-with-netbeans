package view;

// This is a placeholder class required by LoginController.
public class FormLogin {
    public static String tipe = "";
}